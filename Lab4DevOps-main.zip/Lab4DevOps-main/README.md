1. docker build -f Dockerfile.system -t system .

2. docker-compose: docker compose up --build -d
