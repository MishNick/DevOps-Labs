# Lab1DevOps
docker compose up --build -d  - старт и сборка
