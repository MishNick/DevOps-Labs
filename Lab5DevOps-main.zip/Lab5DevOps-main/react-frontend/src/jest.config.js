export const setupFilesAfterEnv = ["./rtl.setup.js"];
